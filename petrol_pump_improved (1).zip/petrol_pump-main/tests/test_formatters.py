import os, sys, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.formatters import format_currency, format_liters


class FormatterTests(unittest.TestCase):
    def test_currency(self):
        self.assertEqual(format_currency(1234.5), "₹1,234.50")
        self.assertEqual(format_currency(None), "₹0.00")
        self.assertEqual(format_currency("abc"), "₹0.00")

    def test_liters(self):
        self.assertEqual(format_liters(10), "10.00 L")
        self.assertEqual(format_liters(None), "0.00 L")


if __name__ == "__main__":
    unittest.main()
