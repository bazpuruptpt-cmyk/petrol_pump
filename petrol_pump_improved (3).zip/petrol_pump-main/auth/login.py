import streamlit as st
from config.supabase_client import get_auth_client
from database.profiles_db import get_profile_by_user_id
import os
import time
from database.duties_db import is_duty_active
from auth.persistent_session import save_persistent_login, clear_persistent_login, render_session_bridge


def _debug_on() -> bool:
    value = os.getenv("LOGIN_DEBUG")
    if value is None:
        try:
            value = st.secrets.get("LOGIN_DEBUG")
        except Exception:
            value = None
    return str(value or "").strip().lower() in {"1", "true", "yes", "on"}


def _diag(step: str, detail: str):
    if _debug_on():
        st.session_state.setdefault("_login_diag", []).append(f"{step}: {detail}")


def authenticate_user(email: str, password: str):
    # Basic brute-force throttle per browser session.
    now = time.time()
    if st.session_state.get("_login_locked_until", 0) > now:
        st.error("Too many failed attempts. Thodi der baad try karo.")
        return None

    st.session_state["_login_diag"] = []
    email = (email or "").strip().lower()
    _diag("1 mode", "service-key (separate login client)" if os.getenv("SUPABASE_SERVICE_KEY") else "legacy (shared client)")
    supabase = get_auth_client()

    try:
        auth_response = supabase.auth.sign_in_with_password({
            "email": email,
            "password": password,
        })
    except Exception as exc:
        _diag("2 supabase sign-in", f"FAILED -> {type(exc).__name__}: {exc}")
        fails = st.session_state.get("_login_fails", 0) + 1
        st.session_state["_login_fails"] = fails
        if fails >= 5:
            st.session_state["_login_locked_until"] = now + 60
            st.session_state["_login_fails"] = 0
        st.error("Invalid login credentials.")
        return None
    st.session_state["_login_fails"] = 0

    user = auth_response.user
    _diag("2 supabase sign-in", f"OK -> auth id {getattr(user, 'id', None)}, email {getattr(user, 'email', None)}")
    if not user:
        st.error("Login failed.")
        return None

    profile = get_profile_by_user_id(user.id)
    if _debug_on():
        from database.profiles_db import fetch_active_profile, get_user_by_id
        _p, _err = fetch_active_profile(user.id)
        _any = get_user_by_id(user.id)
        _diag("3 profile (active)", f"found={bool(_p)} query_error={_err}")
        _diag("3 profile (any)", f"exists={bool(_any)} is_active={(_any or {}).get('is_active')} role={(_any or {}).get('role')}")
    if not profile:
        st.error(
            "Profile not found or inactive. Owner → Users mein is login ka profile "
            "(Auth UUID ke saath, Active) check karo. Agar profile hai to "
            "SUPABASE_SERVICE_KEY set karo ya RLS policy check karo."
        )
        return None

    if profile["role"] == "salesman":
        _duty = is_duty_active(profile["id"])
        _diag("4 duty (salesman)", f"active={_duty}")
        if not _duty:
            st.error("Salesman login allowed only when duty is active.")
            return None

    _diag("5 result", f"logged in as {profile.get('name')} ({profile['role']}), profile id {profile['id']}")
    return {
        "id": profile["id"],
        "name": profile["name"],
        "role": profile["role"],
        "phone": profile.get("phone"),
        "email": email,
    }


def login_page():
    st.title("Petrol Pump Management System")
    st.subheader("Login")

    with st.form("login_form"):
        email = st.text_input("Email")
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("Login")

    if submitted:
        if not email or not password:
            st.error("Email and password required.")
            return

        user = authenticate_user(email, password)
        if user:
            save_persistent_login(user)
            render_session_bridge(token=st.session_state.get("_pump_session_token"))
            st.success("Login successful.")
            st.rerun()

    # Rendered after the login attempt so it shows this attempt's steps.
    if _debug_on() and st.session_state.get("_login_diag"):
        with st.expander("Login diagnostics (LOGIN_DEBUG on)", expanded=True):
            st.code("\n".join(st.session_state["_login_diag"]))


def logout():
    # In legacy mode (no service key) the shared client holds the login session,
    # so sign it out; otherwise only this browser session is cleared.
    try:
        from config.supabase_client import has_service_key, get_supabase_client
        if not has_service_key():
            get_supabase_client().auth.sign_out()
    except Exception:
        pass
    clear_persistent_login()
    render_session_bridge(clear=True)
    st.rerun()
